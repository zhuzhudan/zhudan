package com.study;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.JedisPoolConfig;

import java.util.HashSet;
import java.util.Set;

@SpringBootApplication
public class JedisClusterMain {
    public static void main(String[] args) {
        JedisPoolConfig config = new JedisPoolConfig();
        Set<HostAndPort> jedisClusterNode = new HashSet<HostAndPort>();
        jedisClusterNode.add(new HostAndPort("192.168.1.111", 7001));
        jedisClusterNode.add(new HostAndPort("192.168.1.111", 7002));
        jedisClusterNode.add(new HostAndPort("192.168.1.111", 7003));
        jedisClusterNode.add(new HostAndPort("192.168.1.111", 7004));
        jedisClusterNode.add(new HostAndPort("192.168.1.111", 7005));
        jedisClusterNode.add(new HostAndPort("192.168.1.111", 7006));
        jedisClusterNode.add(new HostAndPort("192.168.1.111", 7007));
        jedisClusterNode.add(new HostAndPort("192.168.1.111", 7008));
        JedisCluster jcd = new JedisCluster(jedisClusterNode, config);
        jcd.set("name:001","lagou");
        String value = jcd.get("name:001");
        System.out.println(value);
    }
}
